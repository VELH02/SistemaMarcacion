# Sistema de marcación ALICAPSA

El servidor está en `Server`. La fuente de datos activa es
`Server/data/alicapsa.sqlite3`. El cliente queda fuera del alcance de estos cambios.

## Ejecución

Desde la raíz del proyecto, en PowerShell:

```powershell
.venv/Scripts/python.exe Server/run.py
```

Abrir http://127.0.0.1:5000/login. Para usar Waitress:

```powershell
cd Server
../.venv/Scripts/python.exe -m waitress --listen=127.0.0.1:5000 --call run:create_app
```

Para reinstalar las dependencias si fuera necesario:

```powershell
python -m venv .venv
.venv/Scripts/python.exe -m pip install -r Server/requirements.txt
```

Conservar la base activa al trasladar el proyecto. Si falta, el inicializador crea
una base nueva con catálogos predeterminados; para recuperar datos existentes se
debe restaurar un respaldo.

## Respaldo y verificación

```powershell
.venv/Scripts/python.exe Server/manage.py check
.venv/Scripts/python.exe Server/manage.py backup
```

Los respaldos están en `Server/backups`. El administrador puede descargar uno desde
Configuración. Para restaurar: detener el servidor, respaldar la base actual y
reemplazarla por el respaldo elegido antes de iniciar de nuevo.

Los JSON/CSV anteriores se retiraron después de verificar su copia comprimida en
`Server/backups/fuentes_migracion_originales.zip`. La aplicación utiliza SQLite.

`ALICAPSA_DB` permite elegir otra ruta absoluta para la base. Conviene utilizar
un archivo local fuera de OneDrive y sincronizar los respaldos cerrados.

## Documentación y distribución

Consultar [la guía del servidor](Server/PLANIFICACION.md) para roles, turnos,
validaciones, bono, convenio dominical y auditoría.

Las 54 pruebas pasaron antes de retirar sus archivos a solicitud del usuario.
También se retiraron plantillas sin referencias, versiones antiguas y temporales.
El cliente y las carpetas biométricas compartidas no se modificaron.

`.venv` contiene las bibliotecas necesarias para ejecutar el servidor. NumPy ocupa
la mayor parte y se usa para leer y servir archivos biométricos; sus módulos y DLL
se conservan. La carpeta del servidor contiene el código, la base y los respaldos.
